# IT0123 DevNet Resource Validation Plan

## Student and Project

- Name: Uriel Joshua V. Cervania
- Section: TN32
- Repository name: `it0123-devnet-resource-plan`

## Purpose

Selecting the correct DevNet resource matters because each resource is designed for a different type of network-automation task. Choosing the right one helps make sure I have the correct level of access, setup, and tools before starting a project.

## Validated Resource Decisions

UC1 – Always-On Sandbox: I selected always-on-sandbox because the main requirement was immediate access for safe, non-admin API practice. Cisco's official Sandbox documentation states that Always-On sandboxes require no reservation, have no setup time, are shared, and restrict administrative access.

UC2 – Reservation Sandbox: I selected reservation-sandbox because the team needs a private environment with administrative access for configuration testing. Cisco's documentation states that Reservation sandboxes provide private access and full administrative access, while requiring a reservation, VPN connection, and some setup time.

UC3 – Learning Lab: I selected learning-lab because the beginner needs guided, step-by-step practice before working independently. The official Cisco learning material I reviewed supports using Learning Labs for structured learning and hands-on practice.

UC4 – Code Exchange: I selected code-exchange because the developer wants to review existing network-automation code before creating a new solution. The official Cisco Code Exchange information shows that it provides code and examples that developers can explore and reuse for development tasks.

## AI Evaluation

I accepted ChatGPT Edu's recommendation to use an Always-On Sandbox for UC1 and a Reservation Sandbox for UC2. I checked these recommendations against Cisco's official Sandbox documentation, which confirmed that Always-On is shared and non-admin with no reservation, while Reservation provides private access and administrative privileges through a reserved environment.

## Validation Evidence

- Validator result: PASS - all validator checks passed
- Command used: python validate_plan.py
- Official Cisco pages reviewed: 
            https://developer.cisco.com/docs/sandbox/getting-started/#always-on-sandboxes
            https://developer.cisco.com/docs/sandbox/getting-started/#reservation-sandboxes
            https://developer.cisco.com/learning/
            https://developer.cisco.com/codeexchange/about/

## Git Evidence

- Initial commit message: "Initial commit: Add README.md from template"
- Validation commit message: "Validate Student Plan"
- Output of `git log --oneline`: 
            03b940b (HEAD -> master) Validate Student Plan
            a8ade7f Initial commit: Add README.md from template

## AI-Use Disclosure

I used ChatGPT Edu to help compare the four use cases, recommend suitable DevNet resources, and improve my explanations. I independently checked the recommendations using official Cisco sources and ran the provided validator to make sure my student_plan.json met the requirements. I also revised the AI-generated explanations to make them clearer and more natural while keeping the information supported by the official evidence.